<?php

namespace App\Services;

use App\Exceptions\ConflictException;
use App\Models\User;
use Illuminate\Support\Facades\Crypt;

class AuthService
{
    /**
     * @throws ConflictException
     */
    public function UserAlreadyRegister(string $email): void
    {
        $user = User::where('email', $email)->first();
        if ($user) {
            throw new ConflictException('Th user already access');
        }
    }

    public function EncryptPassword(string $password): string
    {
        return Crypt::encrypt($password);
    }

    public function DecryptPassword(string $password): string
    {
        return Crypt::decrypt($password);
    }

    public function createUser($user): string
    {
        dd($user);
    }

}
