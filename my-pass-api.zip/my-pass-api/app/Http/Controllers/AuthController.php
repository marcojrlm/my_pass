<?php

namespace App\Http\Controllers;

use App\Exceptions\ConflictException;
use App\Services\AuthService;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\Routing\ResponseFactory;
use Illuminate\Http\Request;
use function Laravel\Prompts\password;

class AuthController extends Controller
{

    protected AuthService $authService;

    public function __construct()
    {
        $this->authService = new AuthService();
    }


    /**
     * @throws ConflictException
     */
    public function signUp(Request $request): \Illuminate\Foundation\Application|\Illuminate\Http\Response|Application|ResponseFactory
    {
        $body = $request->json()->all();

        $this->authService->UserAlreadyRegister($body['email']);
        $body['password'] = $this->authService->EncryptPassword($body['password']);
        $this->authService->createUser($body);

        return response('Created', 200);
    }
}
