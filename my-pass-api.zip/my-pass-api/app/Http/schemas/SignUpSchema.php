<?php

namespace App\Http\schemas;

use App\Exceptions\ErrorHandler;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\ValidationException;

class SignUpSchema
{
    public function handle(Request $request, Closure $next)
    {
        try {
            $this->signUpSchema($request->json()->all());
        } catch (ValidationException $e) {
            return ErrorHandler::unprocessableEntity($e->getMessage());
        }
        return $next($request);
    }

    private function signUpSchema($data): void
    {
        $rules = [
            'userName' => 'required|string|min:5',
            'email' => 'required|string|email',
            'password' => 'required|string|min:8',
            'confirmPassword' => 'required|string|same:password|min:8',
            'picture' => 'required|string',
        ];

        $validator = Validator::make($data, $rules);

        if ($validator->fails()) {
            throw ValidationException::withMessages($validator->errors()->toArray());
        }
    }
}
