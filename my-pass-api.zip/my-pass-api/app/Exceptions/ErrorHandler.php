<?php
// app/Http/Utilities/HttpResponseUtil.php

namespace App\Exceptions;

class ErrorHandler
{
    public static string $unauthorizedMessage = "Acesso negado";
    public static string $conflictMessage = "Conflito";
    public static string $notFoundMessage = "Recurso não encontrado";
    public static string $unprocessableEntityMessage = "Parãmetros inválidos";

    public static function unauthorized(string $message = null): \Illuminate\Http\JsonResponse
    {
        $message = $message ?? self::$unauthorizedMessage;

        return response()->json(['message' => $message], 401);
    }

    public static function notFound(string $message = null): \Illuminate\Http\JsonResponse
    {
        $message = $message ?? self::$notFoundMessage;

        return response()->json(['message' => $message], 404);
    }

    public static function conflict(string $message = null): \Illuminate\Http\JsonResponse
    {
        $message = $message ?? self::$conflictMessage;

        return response()->json(['message' => $message], 409);
    }

    public static function unprocessableEntity(string $message = null): \Illuminate\Http\JsonResponse
    {
        $message = $message ?? self::$unprocessableEntityMessage;

        return response()->json(['message' => $message], 422);
    }

}
